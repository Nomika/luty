﻿var competenciesList = [
    { Id: 1, Name: "Bootstrap", Level: 4, Picture: "bootstrap.svg", Description: "Wersja 3" },
    { Id: 2, Name: "AngularJS", Level: 0, Picture: "angularjs.png", Description: "" },
    { Id: 3, Name: "Angular", Level: 4, Picture: "angular.png", Description: "" },
    { Id: 4, Name: "Ionic", Level: 4, Picture: "ionic.png", Description: "Wersja 2" },
    { Id: 5, Name: "PhoneGap", Level: 1, Picture: "phonegap.png", Description: "Tylko absolutne podstawy" },
    { Id: 6, Name: "ReactJS", Level: 1, Picture: "react.png", Description: "Tylko absolutne podstawy" },
    { Id: 7, Name: "Xamarin", Level: 2, Picture: "xamarin.png", Description: "Bez API dla IOS" },
    { Id: 8, Name: "HTML5", Level: 5, Picture: "html5.png", Description: "Bez WebSockets i Database API" },
    { Id: 9, Name: "CSS3", Level: 4, Picture: "css3.png", Description: "" },
    { Id: 10, Name: "WebAPI", Level: 5, Picture: "webapi.png", Description: "" }
]